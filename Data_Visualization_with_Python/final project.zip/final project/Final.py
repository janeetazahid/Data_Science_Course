import numpy as np 
import pandas as pd 
df_survey=pd.read_csv("Topic_Survey_Assignment.csv")
df_survey.set_index('Unnamed: 0',inplace=True)
#df_survey.rename(columns={0: None},inplace=True)
df_survey.index.names = ['']
df_survey